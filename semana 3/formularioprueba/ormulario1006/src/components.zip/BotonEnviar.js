// BotonEnviar.js
import React from 'react';
import { Button } from 'react-bootstrap';

const BotonEnviar = () => {
  return <Button type="submit">Enviar</Button>;
};

export default BotonEnviar;

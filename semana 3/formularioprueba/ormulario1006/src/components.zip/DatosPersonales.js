import React, { useState } from 'react';

const DatosPersonales = ({ onChange }) => {
  const [nombreUsuario, setNombreUsuario] = useState('');
  const [email, setEmail] = useState('');
  const [genero, setGenero] = useState('');
  const [pais, setPais] = useState('');
  const [aceptaTerminos, setAceptaTerminos] = useState(false);

  const handleNombreUsuarioChange = (event) => {
    setNombreUsuario(event.target.value);
    onChange({ nombreUsuario: event.target.value });
  };

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
    onChange({ email: event.target.value });
  };

  const handleGeneroChange = (event) => {
    setGenero(event.target.value);
    onChange({ genero: event.target.value });
  };

  const handlePaisChange = (event) => {
    setPais(event.target.value);
    onChange({ pais: event.target.value });
  };

  const handleAceptaTerminosChange = (event) => {
    setAceptaTerminos(event.target.checked);
    onChange({ aceptaTerminos: event.target.checked });
  };

  return (
    <div>
      <h2>Datos Personales</h2>
      <input
        type="text"
        placeholder="Nombre de Usuario"
        value={nombreUsuario}
        onChange={handleNombreUsuarioChange}
      />
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={handleEmailChange}
      />
      <div>
        <label>
          Género:
          <input
            type="radio"
            value="Masculino"
            checked={genero === 'Masculino'}
            onChange={handleGeneroChange}
          />
          Masculino
        </label>
        <label>
          <input
            type="radio"
            value="Femenino"
            checked={genero === 'Femenino'}
            onChange={handleGeneroChange}
          />
          Femenino
        </label>
      </div>
      <select value={pais} onChange={handlePaisChange}>
        <option value="">Seleccione un país</option>
        <option value="Argentina">Argentina</option>
        <option value="Brasil">Brasil</option>
        <option value="Chile">Chile</option>
        <option value="Colombia">Colombia</option>
        {/* Agrega más opciones según sea necesario */}
      </select>
      <label>
        <input
          type="checkbox"
          checked={aceptaTerminos}
          onChange={handleAceptaTerminosChange}
        />
        Acepto los términos y condiciones
      </label>
    </div>
  );
};

export default DatosPersonales;

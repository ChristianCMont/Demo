import React, { useState } from 'react';
import DatosPersonales from './DatosPersonales';
import DatosPropiedad from './DatosPropiedad';
import BotonEnviar from './BotonEnviar';

const FormularioInmo = () => {
  const [datosPersonales, setDatosPersonales] = useState({});
  const [datosPropiedad, setDatosPropiedad] = useState({});
  const [mensaje, setMensaje] = useState('');

  const handleDatosPersonalesChange = (newData) => {
    setDatosPersonales({ ...datosPersonales, ...newData });
  };

  const handleDatosPropiedadChange = (newData) => {
    setDatosPropiedad({ ...datosPropiedad, ...newData });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log('Datos Personales:', datosPersonales);
    console.log('Datos de la Propiedad:', datosPropiedad);
    // Aquí puedes enviar los datos al servidor
    setMensaje('Estaremos informando tan pronto como tengamos una propiedad que coincida con sus criterios.');
  };

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card mt-5 p-4">
            <h1 className="mb-4">Ingrese sus datos</h1>
            <form onSubmit={handleSubmit}>
              <DatosPersonales onChange={handleDatosPersonalesChange} />
              <p></p>
              <DatosPropiedad onChange={handleDatosPropiedadChange} />
              <div className="d-grid gap-2">
                <p></p>

                <BotonEnviar />
              </div>
            </form>
            {mensaje && <p className="mt-4">{mensaje}</p>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormularioInmo;
